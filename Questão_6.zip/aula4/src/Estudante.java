public class Estudante {
    String nome;
    String matricula;
    float nota;
    public Estudante(String nome, String matricula, float nota){
        this.nome = nome;
        this.matricula = matricula;
        this.nota = nota;
    }
}
