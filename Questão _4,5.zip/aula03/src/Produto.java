//4° e 5° QUESTÕES:
public class Produto {
    String nome;
    float preco;

    public Produto(String nome, float preco){
        this.nome = nome;
        this.preco = preco;
    }
}
