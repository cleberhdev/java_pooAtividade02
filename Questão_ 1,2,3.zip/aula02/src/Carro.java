// Classe da 1° Questão:
public class Carro {
    String marca;
    String modelo;
    String cor;
    int ano;
    float preco;
    public Carro(String marca, String modelo, String cor, int ano, float preco){
        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;
        this.ano = ano;
        this.preco = preco;
    }
}
